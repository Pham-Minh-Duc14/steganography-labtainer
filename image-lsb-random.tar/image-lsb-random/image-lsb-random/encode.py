from PIL import Image
import random
import sys
img = Image.open("secret_image.png")
pixels = img.load()
width, height = img.size
total_pixels = width * height

msg = input("Nhập thông điệp bí mật: ")
msg += "@@@@" 
bin_msg = ''.join(format(ord(c), '08b') for c in msg)

key = input("Nhập khóa bí mật (Mật khẩu): ")
random.seed(key) # Dùng mật khẩu làm hạt giống ngẫu nhiên

if len(bin_msg) > total_pixels:
    print("Thông điệp quá dài!")
    sys.exit()

# Tạo danh sách tọa độ và xáo trộn dựa trên Mật khẩu
indices = list(range(total_pixels))
random.shuffle(indices)

for i, bit in enumerate(bin_msg):
    idx = indices[i]
    x = idx % width
    y = idx // width
    r, g, b = pixels[x, y][:3]
    pixels[x, y] = ((r & 254) | int(bit), g, b)

img.save("stego_random.png")
print("Thành công! Thông điệp đã bị xáo trộn vị trí và giấu vào stego_random.png")
