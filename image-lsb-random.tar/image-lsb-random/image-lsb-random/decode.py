from PIL import Image
import random
import sys

try:
    img = Image.open("stego_random.png")
except FileNotFoundError:
    print("Không tìm thấy file stego_random.png! Hãy chạy file encode.py trước.")
    sys.exit()
    
pixels = img.load()
width, height = img.size

key = input("Nhập khóa bí mật để giải mã: ")
random.seed(key) # Phải nhập đúng mật khẩu thì hàm shuffle mới sinh ra danh sách y hệt lúc mã hóa

indices = list(range(width * height))
random.shuffle(indices)

bits = ""
chars = ""

for idx in indices:
    x = idx % width
    y = idx // width
    bits += str(pixels[x, y][0] & 1)
    
    if len(bits) == 8:
        chars += chr(int(bits, 2))
        bits = ""
        if chars.endswith("@@@@"):
            print("Thông điệp giải mã được:", chars[:-4])
            sys.exit()

print("Giải mã thất bại! Có thể bạn đã nhập sai mật khẩu.")
