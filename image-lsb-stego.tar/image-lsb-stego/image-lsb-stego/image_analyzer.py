from PIL import Image
def analyze(image_path):
    try:
        img = Image.open(image_path)
        print(f"File: {image_path}\nKích thước: {img.size}\nĐịnh dạng: {img.format}\nChế độ màu: {img.mode}")
    except Exception as e:
        print(f"Lỗi đọc ảnh: {e}")
if __name__ == "__main__":
    analyze("secret_image.png")
