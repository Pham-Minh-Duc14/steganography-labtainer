from PIL import Image
def encode_lsb(image_path, text, output_path):
    try:
        img = Image.open(image_path).convert('RGB')
        pixels = img.load()
        binary_text = ''.join(format(ord(char), '08b') for char in text) + '11111111'
        width, height = img.size
        idx = 0
        for y in range(height):
            for x in range(width):
                if idx < len(binary_text):
                    r, g, b = pixels[x, y]
                    r = (r & ~1) | int(binary_text[idx])
                    pixels[x, y] = (r, g, b)
                    idx += 1
                else: break
            if idx >= len(binary_text): break
        img.save(output_path)
        print(f"Thành công! Tin nhắn đã được giấu vào file: {output_path}")
    except Exception as e:
        print(f"Lỗi: {e}")
if __name__ == "__main__":
    msg = input("Nhập thông điệp bí mật bạn muốn giấu: ")
    if msg: encode_lsb("secret_image.png", msg, "stego_image.png")
