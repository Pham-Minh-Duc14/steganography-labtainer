from PIL import Image
def decode_lsb(image_path):
    try:
        img = Image.open(image_path).convert('RGB')
        pixels = img.load()
        width, height = img.size
        binary_text = ""
        for y in range(height):
            for x in range(width):
                r, g, b = pixels[x, y]
                binary_text += str(r & 1)
        chars = [binary_text[i:i+8] for i in range(0, len(binary_text), 8)]
        decoded_text = ""
        for char in chars:
            if char == '11111111': break
            decoded_text += chr(int(char, 2))
        print(f"Thông điệp giải mã được: {decoded_text}")
    except Exception as e:
        print("Lỗi giải mã:", e)
if __name__ == "__main__":
    decode_lsb("stego_image.png")
