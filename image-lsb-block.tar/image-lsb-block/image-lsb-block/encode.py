from PIL import Image
import sys

img = Image.open("secret_image.png")
pixels = img.load()
width, height = img.size

B = 4 # Kích thước khối 4x4
blocks_x = width // B
blocks_y = height // B
max_bits = blocks_x * blocks_y

msg = input("Nhập thông điệp bí mật: ")
msg += "@@@@"
bin_msg = ''.join(format(ord(c), '08b') for c in msg)

if len(bin_msg) > max_bits:
    print(f"Thông điệp quá dài! Ảnh này chỉ chứa tối đa {max_bits} bits ({max_bits//8} ký tự) bằng phương pháp khối.")
    sys.exit()

for i, bit_char in enumerate(bin_msg):
    bit = int(bit_char)
    # Xác định tọa độ bắt đầu của khối thứ i
    bx = (i % blocks_x) * B
    by = (i // blocks_x) * B
    
    # Tính tổng LSB của kênh Đỏ (Red) trong toàn bộ khối 4x4
    lsb_sum = 0
    for dx in range(B):
        for dy in range(B):
            lsb_sum += pixels[bx + dx, by + dy][0] & 1
            
    parity = lsb_sum % 2
    
    # Nếu tính chẵn lẻ không khớp với bit cần giấu, lật bit LSB của pixel đầu tiên trong khối
    if parity != bit:
        r, g, b = pixels[bx, by][:3]
        pixels[bx, by] = (r ^ 1, g, b) # Dùng XOR để lật bit 0 thành 1 và ngược lại

img.save("stego_block.png")
print("Thành công! Thông điệp đã được phân bổ vào các khối 4x4 và lưu thành stego_block.png")
