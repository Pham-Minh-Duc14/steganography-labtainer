from PIL import Image
import sys

try:
    img = Image.open("stego_block.png")
except FileNotFoundError:
    print("Không tìm thấy file stego_block.png! Hãy chạy file encode.py trước.")
    sys.exit()
    
pixels = img.load()
width, height = img.size
B = 4
blocks_x = width // B
blocks_y = height // B

bits = ""
chars = ""

# Quét qua từng khối từ trái sang phải, trên xuống dưới
for by_idx in range(blocks_y):
    for bx_idx in range(blocks_x):
        bx = bx_idx * B
        by = by_idx * B
        
        # Tính tổng LSB của khối để xác định bit được giấu
        lsb_sum = 0
        for dx in range(B):
            for dy in range(B):
                lsb_sum += pixels[bx + dx, by + dy][0] & 1
                
        bits += str(lsb_sum % 2)
        
        # Cứ gom đủ 8 bit thì dịch ra 1 ký tự
        if len(bits) == 8:
            chars += chr(int(bits, 2))
            bits = ""
            if chars.endswith("@@@@"):
                print("Thông điệp giải mã được:", chars[:-4])
                sys.exit()

print("Không tìm thấy điểm kết thúc chuỗi. Giải mã thất bại!")
